<x-layout.user.app>
    <x-slot name="head">
        <meta name="description" content="">
        <meta name="author" content="">
        <title> Dashboard | {{ config('app.name') }}</title>
    </x-slot>

    <section class="content">

    </section>
</x-layout.user.app>
