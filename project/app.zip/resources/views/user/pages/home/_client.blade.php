<section class="client-area">
    <div class="clients clients-marquee d-flex align-items-center">
        <div class="client-logo simple-shadow">
            <img src="{{ asset('themes/guest') }}/assets/imgs/client-logo1.svg" alt="Client" />
        </div>
        <div class="client-logo simple-shadow">
            <img src="{{ asset('themes/guest') }}/assets/imgs/client-logo2.svg" alt="Client" />
        </div>
        <div class="client-logo simple-shadow">
            <img src="{{ asset('themes/guest') }}/assets/imgs/client-logo3.svg" alt="Client" />
        </div>
        <div class="client-logo simple-shadow">
            <img src="{{ asset('themes/guest') }}/assets/imgs/client-logo4.svg" alt="Client" />
        </div>
        <div class="client-logo simple-shadow">
            <img src="{{ asset('themes/guest') }}/assets/imgs/client-logo5.svg" alt="Client" />
        </div>
        <div class="client-logo simple-shadow">
            <img src="{{ asset('themes/guest') }}/assets/imgs/client-logo2.svg" alt="Client" />
        </div>
        <div class="client-logo simple-shadow">
            <img src="{{ asset('themes/guest') }}/assets/imgs/client-logo3.svg" alt="Client" />
        </div>
        <div class="client-logo simple-shadow">
            <img src="{{ asset('themes/guest') }}/assets/imgs/client-logo4.svg" alt="Client" />
        </div>
        <div class="client-logo simple-shadow">
            <img src="{{ asset('themes/guest') }}/assets/imgs/client-logo5.svg" alt="Client" />
        </div>
        <div class="client-logo simple-shadow">
            <img src="{{ asset('themes/guest') }}/assets/imgs/client-logo2.svg" alt="Client" />
        </div>
        <div class="client-logo" style="min-width: 0;"></div>
    </div>
</section>