<div class="header-bar">
    <div class="custom-container">
        <div class="header-bar-body d-flex align-items-center justify-content-between">
            <div class="left">
                
            </div>
            <div class="right">
                <p>
                    Level up your business with <a href="#" data-word="{{ config('app.name') }}" id="dataWord"> {{ config('app.name') }} </a>
                </p>
            </div>
        </div>
    </div>
</div>