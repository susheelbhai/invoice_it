
<a href="{{ $href }}" class="dropdown-item ai-icon ">
    <i class="me-2" data-feather="{{ $icon }}"></i>
    
    <span class="ms-2">{{ $name }} </span>
</a>