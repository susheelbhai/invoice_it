<script src="{{ asset('themes/theme1') }}/vendor/global/global.min.js"></script>
<script src="{{ asset('themes/theme1') }}/vendor/chart.js/Chart.bundle.min.js"></script>
<script src="{{ asset('themes/theme1') }}/vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>

<!-- Apex Chart -->
<script src="{{ asset('themes/theme1') }}/vendor/apexchart/apexchart.js"></script>

<script src="{{ asset('themes/theme1') }}/vendor/chart.js/Chart.bundle.min.js"></script>

<!-- Chart piety plugin files -->
<script src="{{ asset('themes/theme1') }}/vendor/peity/jquery.peity.min.js"></script>
<script src="{{ asset('themes/theme1') }}/vendor/nouislider/nouislider.min.js"></script>
<script src="{{ asset('themes/theme1') }}/vendor/wnumb/wNumb.js"></script>

<!-- Dashboard 1 -->
<script src="{{ asset('themes/theme1') }}/js/dashboard/dashboard-1.js"></script>

<script src="{{ asset('themes/theme1') }}/vendor/owl-carousel/owl.carousel.js"></script>

<script src="{{ asset('themes/theme1') }}/js/custom.min.js"></script>
<script src="{{ asset('themes/theme1') }}/js/dlabnav-init.js"></script>
<script src="{{ asset('themes/theme1') }}/js/demo.js"></script>
<script src="{{ asset('themes/theme1') }}/js/styleSwitcher.js"></script>

<script src="{{ asset('themes/theme1') }}/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="{{ asset('themes/theme1') }}/js/plugins-init/datatables.init.js"></script>

<!-- Select2 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
  $(".select2_single").select2({
      placeholder: "Select ...",
      allowClear: true
  });
  $(".select2_multiple").select2({
      placeholder: "Select ...",
      allowClear: true
  });
</script>