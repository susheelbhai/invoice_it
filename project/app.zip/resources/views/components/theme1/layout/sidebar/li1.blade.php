<li>
    <a href="{{ $href }}" class="" aria-expanded="false">
        <i class="{{ $icon }}"></i>
        <span class="nav-text">{{ $name }}</span>
    </a>
</li>
