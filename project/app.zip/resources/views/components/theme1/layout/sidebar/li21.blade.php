<li>
    <a href="{{ $href }}">
        {{ $name }}
    </a>
</li>
