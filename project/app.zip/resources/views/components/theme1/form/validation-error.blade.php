<span class="text-danger">
    {{ $value }}
</span>