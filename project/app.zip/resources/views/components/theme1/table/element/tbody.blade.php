<tbody  {{ $attributes }}>
    {{ $slot }}
</tbody>