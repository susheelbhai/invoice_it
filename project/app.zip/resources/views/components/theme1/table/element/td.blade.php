<td colspan="{{ $colspan }}" {{ $attributes }}>
    {{ $data2 ?? '' }}
    {{ $slot }}
</td>