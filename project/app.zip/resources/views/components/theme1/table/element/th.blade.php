<th colspan="{{ $colspan }}"  {{ $attributes }}>
    {{ $data2 ?? '' }}
</th>