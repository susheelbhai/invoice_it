<tr   {{ $attributes }}>
    {{ $slot }}
</tr>