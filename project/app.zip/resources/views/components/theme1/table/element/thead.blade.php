<thead  {{ $attributes }}>
    {{ $slot }}
</thead>