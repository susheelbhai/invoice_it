<x-table.element.th data="Applied Date" />
<x-table.element.th data="Business Logo" />
<x-table.element.th data="Business Name" />
<x-table.element.th data="Owner Name" />
<x-table.element.th data="City" />
<x-table.element.th data="Status" />
