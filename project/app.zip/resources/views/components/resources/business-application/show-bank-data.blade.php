<x-table.element.tr>
    <x-table.element.th data="Bank Name" />
    <x-table.element.td :data="$data2['bank_name']" />
</x-table.element.tr>
<x-table.element.tr>
    <x-table.element.th data="Bank Address" />
    <x-table.element.td :data="$data2['bank_address']" />
</x-table.element.tr>
<x-table.element.tr>
    <x-table.element.th data="IFSC" />
    <x-table.element.td :data="$data2['ifsc']" />
</x-table.element.tr>
<x-table.element.tr>
    <x-table.element.th data="Account Number" />
    <x-table.element.td :data="$data2['account_number']" />
</x-table.element.tr>
<x-table.element.tr>
    <x-table.element.th data="Account Holder Name" />
    <x-table.element.td :data="$data2['account_holder_name']" />
</x-table.element.tr>
<x-table.element.tr>
    <x-table.element.th data="Payment Terms" />
    <x-table.element.td :data="$data2['payment_terms']" />
</x-table.element.tr>