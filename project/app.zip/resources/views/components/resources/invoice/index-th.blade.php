<x-table.element.th data="Invoice Number" />
<x-table.element.th data="Date" />
<x-table.element.th data="Customer" />
<x-table.element.th data="Amount" />
<x-table.element.th data="Download" />
<x-table.element.th data="Action" />
