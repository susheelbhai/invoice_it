<x-table.element.td :data="$data2['sku']" />
<x-table.element.td :data="$data2['hsn_code']" />
<x-table.element.td :data="$data2['name']" />
<x-table.element.td :data="$data2['sale_price']" />
