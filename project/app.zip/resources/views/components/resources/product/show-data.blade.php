<x-table.element.tr>
    <x-table.element.th data="Product SKU" />
    <x-table.element.td :data="$data2['sku']" />
</x-table.element.tr>
<x-table.element.tr>
    <x-table.element.th data="Product Name" />
    <x-table.element.td :data="$data2['name']" />
</x-table.element.tr>
<x-table.element.tr>
    <x-table.element.th data="HSN Code" />
    <x-table.element.td :data="$data2['hsn_code']" />
</x-table.element.tr>
<x-table.element.tr>
    <x-table.element.th data="Product Description" />
    <x-table.element.td :data="$data2['description']" />
</x-table.element.tr>
<x-table.element.tr>
    <x-table.element.th data="Sale Price" />
    <x-table.element.td :data="$data2['sale_price']" />
</x-table.element.tr>
<x-table.element.tr>
    <x-table.element.th data="Quantity" />
    <x-table.element.td :data="$data2['quantity']" />
</x-table.element.tr>
