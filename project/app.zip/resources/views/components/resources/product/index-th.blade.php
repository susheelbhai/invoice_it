<x-table.element.th data="SKU" />
<x-table.element.th data="HSN Code" />
<x-table.element.th data="Name" />
<x-table.element.th data="Sale Price" />
