<x-layout.header.profile-li name=" My Profile" href="#" icon="user" />
<x-layout.header.profile-li name="Settings" href="#" icon="settings" />