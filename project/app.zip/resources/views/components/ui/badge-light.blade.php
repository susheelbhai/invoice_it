<span class="badge badge-{{ $size }} light badge-{{ $type }}">
    {{ $title }}
</span>