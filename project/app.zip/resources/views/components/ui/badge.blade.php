<span class="badge badge-{{ $size }} badge-{{ $type }}">
    {{ $title }}
</span>